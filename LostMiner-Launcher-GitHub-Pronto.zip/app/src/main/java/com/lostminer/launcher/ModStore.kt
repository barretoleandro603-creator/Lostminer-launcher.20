package com.lostminer.launcher

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.zip.ZipException
import java.util.zip.ZipInputStream

/**
 * Guarda os mods importados (.ls) e quais estão ligados.
 *
 * Formato .ls (versão 1): arquivo ZIP com um "mod.json" na raiz:
 *   { "name": "Meu Mod", "version": "1.0", "game": "lostminer", "ls_version": 1 }
 * Os demais arquivos do ZIP (por exemplo imagens .png) fazem parte do mod.
 */
class ModStore(private val ctx: Context) {

    data class Mod(val id: String, val name: String, val version: String, val enabled: Boolean)
    data class Result(val ok: Boolean, val message: String)

    private val root = File(ctx.filesDir, "mods")
    private val indexFile = File(ctx.filesDir, "mods_index.json")

    companion object {
        private val LOCK = Any()
        private const val MAX_ENTRIES = 2000
        private const val MAX_TOTAL_BYTES = 100L * 1024 * 1024
    }

    fun list(): List<Mod> = synchronized(LOCK) {
        readIndex().filter { File(root, it.id).isDirectory }
    }

    /** total, ligados, desligados */
    fun counts(): Triple<Int, Int, Int> {
        val mods = list()
        val on = mods.count { it.enabled }
        return Triple(mods.size, on, mods.size - on)
    }

    fun setEnabled(id: String, enabled: Boolean) {
        synchronized(LOCK) {
            writeIndex(readIndex().map { if (it.id == id) it.copy(enabled = enabled) else it })
        }
    }

    fun delete(id: String) {
        synchronized(LOCK) {
            File(root, id).deleteRecursively()
            writeIndex(readIndex().filter { it.id != id })
        }
    }

    fun importMod(uri: Uri): Result = synchronized(LOCK) { doImport(uri) }

    /** Copia só os mods LIGADOS para a pasta "active_mods" e devolve quantos são. */
    fun prepareActive(): Int = synchronized(LOCK) {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val dir = File(base, "active_mods")
        dir.deleteRecursively()
        dir.mkdirs()
        val on = readIndex().filter { it.enabled && File(root, it.id).isDirectory }
        val arr = JSONArray()
        for (m in on) {
            File(root, m.id).copyRecursively(File(dir, m.id), true)
            arr.put(JSONObject().put("id", m.id).put("name", m.name).put("version", m.version))
        }
        File(dir, "active_mods.json").writeText(arr.toString())
        on.size
    }

    // ---------- importação ----------

    private fun doImport(uri: Uri): Result {
        val fileName = displayName(uri)
        if (fileName == null || !fileName.lowercase().endsWith(".ls")) {
            return Result(false, "O arquivo precisa ter a extensão .ls")
        }
        root.mkdirs()
        val id = UUID.randomUUID().toString().take(8)
        val tmp = File(root, ".tmp-$id")
        try {
            extract(uri, tmp)

            val manifest = File(tmp, "mod.json")
            if (!manifest.isFile) return fail(tmp, "mod.json não encontrado na raiz do arquivo")
            val json = try {
                JSONObject(manifest.readText())
            } catch (e: Exception) {
                return fail(tmp, "mod.json inválido")
            }

            val name = json.optString("name").trim()
            if (name.isEmpty() || name.length > 60) return fail(tmp, "Nome do mod ausente ou longo demais")
            if (!json.optString("game").equals("lostminer", ignoreCase = true)) {
                return fail(tmp, "Mod não é compatível com o LostMiner")
            }
            if (json.optInt("ls_version", 0) != 1) {
                return fail(tmp, "Versão do formato .ls não suportada")
            }
            val version = json.optString("version", "1.0").trim().ifEmpty { "1.0" }

            val current = readIndex()
            if (current.any { it.name == name && it.version == version }) {
                return fail(tmp, "Este mod já foi importado")
            }

            val target = File(root, id)
            if (!tmp.renameTo(target)) return fail(tmp, "Não foi possível salvar o mod")
            writeIndex(current + Mod(id, name, version, false))
            return Result(true, name)
        } catch (e: ZipException) {
            return fail(tmp, "Arquivo inválido: não é um pacote .ls (ZIP) legível")
        } catch (e: IOException) {
            return fail(tmp, e.message ?: "Falha ao ler o arquivo")
        } catch (e: Exception) {
            return fail(tmp, "Falha inesperada ao importar")
        }
    }

    private fun fail(tmp: File, msg: String): Result {
        tmp.deleteRecursively()
        return Result(false, msg)
    }

    private fun extract(uri: Uri, dest: File) {
        dest.deleteRecursively()
        dest.mkdirs()
        val destPath = dest.canonicalPath + File.separator
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw IOException("Não foi possível abrir o arquivo")
        var entries = 0
        var total = 0L
        ZipInputStream(input.buffered()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                entries++
                if (entries > MAX_ENTRIES) throw IOException("Mod com arquivos demais")
                val name = entry.name.replace('\\', '/')
                if (name.startsWith("/") || name.split('/').any { it == ".." }) {
                    throw IOException("Mod com caminho inseguro")
                }
                val out = File(dest, name)
                if (!out.canonicalPath.startsWith(destPath)) throw IOException("Mod com caminho inseguro")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { os ->
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_TOTAL_BYTES) throw IOException("Mod grande demais")
                            os.write(buf, 0, n)
                        }
                    }
                }
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
        if (entries == 0) throw ZipException("vazio")
    }

    private fun displayName(uri: Uri): String? =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    // ---------- índice salvo em disco ----------

    private fun readIndex(): List<Mod> {
        if (!indexFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(indexFile.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Mod(o.getString("id"), o.getString("name"), o.optString("version", "1.0"), o.optBoolean("enabled", false))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeIndex(mods: List<Mod>) {
        val arr = JSONArray()
        mods.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("version", it.version).put("enabled", it.enabled))
        }
        val tmp = File(ctx.filesDir, "mods_index.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(indexFile)) {
            indexFile.writeText(arr.toString())
            tmp.delete()
        }
    }
}
