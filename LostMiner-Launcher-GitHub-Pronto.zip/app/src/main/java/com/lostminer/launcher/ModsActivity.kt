package com.lostminer.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ModsActivity : Activity() {

    private val reqImport = 42
    private lateinit var store: ModStore
    private lateinit var list: LinearLayout
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ModStore(this)
        Ui.immersive(this)
        build()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        Ui.immersive(this)
    }

    private fun build() {
        val pad = Ui.dp(this, 16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "MODS"
            setTextColor(Ui.TEXT)
            textSize = 30f
            typeface = Ui.mono
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = pad })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.neonBg(this@ModsActivity, Ui.PANEL, Ui.NEON)
            setPadding(pad, pad, pad, pad)
        }
        root.addView(panel, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        panel.addView(Ui.button(this, "IMPORTAR MODS\n(Arquivos .ls)", 20f) { pickFile() },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = pad })

        empty = TextView(this).apply {
            text = "Nenhum mod importado"
            setTextColor(Ui.NEON_DIM)
            textSize = 16f
            typeface = Ui.mono
            gravity = Gravity.CENTER
        }
        panel.addView(empty, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        panel.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        root.addView(Ui.button(this, "◀  SAIR", 20f) { finish() },
            LinearLayout.LayoutParams(Ui.dp(this, 180), WRAP_CONTENT).apply { topMargin = pad })

        setContentView(root)
    }

    private fun refresh() {
        val mods = store.list()
        list.removeAllViews()
        empty.visibility = if (mods.isEmpty()) View.VISIBLE else View.GONE
        for (m in mods) {
            list.addView(row(m), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                bottomMargin = Ui.dp(this@ModsActivity, 10)
            })
        }
    }

    private fun row(m: ModStore.Mod): View {
        val ctx = this
        val p = Ui.dp(ctx, 12)
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(p, p, p, p)
            background = Ui.neonBg(ctx, Ui.BG, if (m.enabled) Ui.GREEN else Ui.NEON_DIM)
            setOnClickListener { toggle(m) }
        }

        val info = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        info.addView(TextView(ctx).apply {
            text = m.name
            setTextColor(Ui.TEXT)
            textSize = 18f
            typeface = Ui.mono
        })
        info.addView(TextView(ctx).apply {
            text = (if (m.enabled) "● LIGADO" else "● DESLIGADO") + "   v${m.version}"
            setTextColor(if (m.enabled) Ui.GREEN else Ui.RED)
            textSize = 13f
            typeface = Ui.mono
        })
        r.addView(info, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        r.addView(Ui.button(ctx, if (m.enabled) "DESLIGAR" else "LIGAR", 14f) { toggle(m) },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = p })
        r.addView(Ui.button(ctx, "APAGAR", 14f) { confirmDelete(m) },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        return r
    }

    private fun toggle(m: ModStore.Mod) {
        store.setEnabled(m.id, !m.enabled)
        refresh()
    }

    private fun confirmDelete(m: ModStore.Mod) {
        AlertDialog.Builder(this)
            .setTitle("Apagar mod?")
            .setMessage(m.name)
            .setPositiveButton("APAGAR") { _, _ ->
                store.delete(m.id)
                refresh()
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, reqImport)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqImport || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val res = try {
                store.importMod(uri)
            } catch (e: Exception) {
                ModStore.Result(false, "Falha inesperada ao importar")
            }
            runOnUiThread {
                refresh()
                AlertDialog.Builder(this)
                    .setTitle(if (res.ok) "MOD IMPORTADO COM SUCESSO" else "ERRO AO IMPORTAR")
                    .setMessage(res.message)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }.start()
    }
}
